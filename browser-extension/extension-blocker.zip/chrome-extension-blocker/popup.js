document.addEventListener('DOMContentLoaded', async () => {
  const enableToggle = document.getElementById('enableToggle');
  const domainInput = document.getElementById('domainInput');
  const addDomainBtn = document.getElementById('addDomain');
  const domainList = document.getElementById('domainList');
  const extensionList = document.getElementById('extensionList');
  const currentUrl = document.getElementById('currentUrl');
  const siteStatus = document.getElementById('siteStatus');
  const refreshBtn = document.getElementById('refreshBtn');

  let blockedDomains = [];
  let isEnabled = true;

  await init();

  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      currentUrl.textContent = new URL(tab.url).hostname;
    }

    const result = await sendMessage({ action: 'getBlockedDomains' });
    blockedDomains = result.blockedDomains || [];
    isEnabled = result.enabled !== false;
    enableToggle.checked = isEnabled;

    updateSiteStatus();
    renderDomainList();
    await loadExtensions();
  }

  function updateSiteStatus() {
    const hostname = currentUrl.textContent;
    const isBlocked = blockedDomains.some(domain => {
      const regex = new RegExp(
        '^' + domain.replace(/\*/g, '.*').replace(/\./g, '\\.') + '$'
      );
      return regex.test(hostname) || hostname.endsWith('.' + domain);
    });

    if (isBlocked && isEnabled) {
      siteStatus.textContent = '⚠️ 已拦截';
      siteStatus.className = 'status blocked';
    } else {
      siteStatus.textContent = '✅ 正常';
      siteStatus.className = 'status safe';
    }
  }

  function renderDomainList() {
    domainList.innerHTML = '';

    if (blockedDomains.length === 0) {
      domainList.innerHTML = '<div class="empty">暂无禁止域名</div>';
      return;
    }

    blockedDomains.forEach((domain, index) => {
      const item = document.createElement('div');
      item.className = 'domain-item';
      item.innerHTML = `
        <span>${domain}</span>
        <button class="delete-btn" data-index="${index}">删除</button>
      `;
      domainList.appendChild(item);
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const index = parseInt(btn.dataset.index);
        blockedDomains.splice(index, 1);
        await saveDomains();
        renderDomainList();
        updateSiteStatus();
      });
    });
  }

  async function loadExtensions() {
    const result = await sendMessage({ action: 'getExtensions' });
    const extensions = result.extensions || [];

    extensionList.innerHTML = '';

    if (extensions.length === 0) {
      extensionList.innerHTML = '<div class="empty">未发现其他扩展</div>';
      return;
    }

    extensions.forEach(ext => {
      const item = document.createElement('div');
      item.className = 'extension-item';
      item.innerHTML = `
        <div class="ext-info">
          <img src="${ext.icons?.[0]?.url || 'icons/icon16.png'}" alt="" class="ext-icon">
          <div class="ext-details">
            <div class="ext-name">${ext.name}</div>
            <div class="ext-version">${ext.version}</div>
          </div>
        </div>
        <label class="switch small">
          <input type="checkbox" ${ext.enabled ? 'checked' : ''} 
                 data-id="${ext.id}" class="ext-toggle">
          <span class="slider"></span>
        </label>
      `;
      extensionList.appendChild(item);
    });

    document.querySelectorAll('.ext-toggle').forEach(toggle => {
      toggle.addEventListener('change', async (e) => {
        const extId = e.target.dataset.id;
        await sendMessage({
          action: 'toggleExtension',
          extensionId: extId,
          enabled: e.target.checked
        });
      });
    });
  }

  addDomainBtn.addEventListener('click', async () => {
    const domain = domainInput.value.trim().toLowerCase();

    if (!domain) return;

    if (!/^(\*\.)?([a-z0-9-]+\.)+[a-z]{2,}$/.test(domain)) {
      alert('请输入有效的域名格式，如：example.com 或 *.example.com');
      return;
    }

    if (!blockedDomains.includes(domain)) {
      blockedDomains.push(domain);
      await saveDomains();
      domainInput.value = '';
      renderDomainList();
      updateSiteStatus();
    }
  });

  domainInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addDomainBtn.click();
  });

  enableToggle.addEventListener('change', async () => {
    isEnabled = enableToggle.checked;
    await saveDomains();
    updateSiteStatus();
  });

  refreshBtn.addEventListener('click', () => {
    location.reload();
  });

  async function saveDomains() {
    await sendMessage({
      action: 'setBlockedDomains',
      domains: blockedDomains,
      enabled: isEnabled
    });
  }

  function sendMessage(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, resolve);
    });
  }
});