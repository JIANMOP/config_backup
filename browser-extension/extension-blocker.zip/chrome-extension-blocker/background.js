// 默认禁止扩展的域名列表
const DEFAULT_BLOCKED_DOMAINS = [
  'example.com',
  'sensitive-site.com',
  'bank.com'
];

// 记录每个标签页之前禁用的扩展ID（用于恢复）
const tabDisabledExtensions = new Map();

// 当前扩展自己的ID（不能禁用自己）
const SELF_ID = chrome.runtime.id;

// 初始化存储
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['blockedDomains'], (result) => {
    if (!result.blockedDomains) {
      chrome.storage.sync.set({ 
        blockedDomains: DEFAULT_BLOCKED_DOMAINS,
        enabled: true 
      });
    }
  });
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    handleTabChange(tabId, tab.url);
  }
});

// 监听标签页切换
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab.url) {
      handleTabChange(tab.id, tab.url);
    }
  });
});

// 监听标签页关闭，恢复该标签页禁用的扩展
chrome.tabs.onRemoved.addListener((tabId) => {
  restoreExtensionsForTab(tabId);
});

// 核心：处理标签页变化，判断是否需要禁用/恢复扩展
async function handleTabChange(tabId, url) {
  try {
    const result = await chrome.storage.sync.get(['blockedDomains', 'enabled']);
    if (!result.enabled) {
      // 功能被关闭，恢复所有
      await restoreAllExtensions();
      return;
    }

    const blockedDomains = result.blockedDomains || [];
    const currentHostname = new URL(url).hostname;

    // 检查当前域名是否在禁止列表中
    const isBlocked = blockedDomains.some(domain => {
      const regex = new RegExp(
        '^' + domain.replace(/\*/g, '.*').replace(/\./g, '\\.') + '$'
      );
      return regex.test(currentHostname) || currentHostname.endsWith('.' + domain);
    });

    if (isBlocked) {
      // 该域名需要禁用其他扩展
      await disableOtherExtensions(tabId);
      chrome.action.setBadgeText({ text: '⚠️', tabId: tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#FF4444' });
    } else {
      // 该域名不需要禁用，恢复之前为此标签页禁用的扩展
      await restoreExtensionsForTab(tabId);
      chrome.action.setBadgeText({ text: '', tabId: tabId });
    }
  } catch (error) {
    console.error('处理标签页失败:', error);
  }
}

// 禁用其他扩展（排除当前扩展）
async function disableOtherExtensions(tabId) {
  try {
    const allExtensions = await chrome.management.getAll();
    
    // 获取当前为此标签页已禁用的扩展（避免重复记录）
    const alreadyDisabled = tabDisabledExtensions.get(tabId) || new Set();
    
    for (const ext of allExtensions) {
      // 跳过：当前扩展、主题、应用、已禁用的扩展
      if (ext.id === SELF_ID) continue;
      if (ext.type !== 'extension') continue;
      if (!ext.enabled) {
        // 记录原本就是禁用的，避免恢复时误开启
        alreadyDisabled.add(ext.id);
        continue;
      }
      
      // 禁用扩展
      await chrome.management.setEnabled(ext.id, false);
      alreadyDisabled.add(ext.id);
      console.log(`已禁用扩展: ${ext.name} (${ext.id})`);
    }
    
    // 保存该标签页禁用的扩展列表
    tabDisabledExtensions.set(tabId, alreadyDisabled);
  } catch (error) {
    console.error('禁用扩展失败:', error);
  }
}

// 恢复指定标签页禁用的扩展
async function restoreExtensionsForTab(tabId) {
  const disabledSet = tabDisabledExtensions.get(tabId);
  if (!disabledSet || disabledSet.size === 0) return;
  
  try {
    const allExtensions = await chrome.management.getAll();
    const allExtMap = new Map(allExtensions.map(e => [e.id, e]));
    
    for (const extId of disabledSet) {
      const ext = allExtMap.get(extId);
      // 只恢复类型为 extension 且当前处于禁用状态的
      if (ext && ext.type === 'extension' && !ext.enabled) {
        await chrome.management.setEnabled(extId, true);
        console.log(`已恢复扩展: ${ext.name} (${extId})`);
      }
    }
    
    // 清除记录
    tabDisabledExtensions.delete(tabId);
  } catch (error) {
    console.error('恢复扩展失败:', error);
  }
}

// 恢复所有扩展（用于关闭功能时）
async function restoreAllExtensions() {
  for (const [tabId, disabledSet] of tabDisabledExtensions) {
    await restoreExtensionsForTab(tabId);
  }
  tabDisabledExtensions.clear();
}

// 监听 storage 变化（用户修改域名列表或关闭功能时）
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync') {
    // 如果用户关闭了功能或修改了域名，重新处理当前活动标签页
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url) {
        handleTabChange(tabs[0].id, tabs[0].url);
      }
    });
  }
});

// 消息处理（供 popup 调用）
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getExtensions') {
    chrome.management.getAll((extensions) => {
      const userExtensions = extensions.filter(ext => 
        ext.id !== SELF_ID && ext.type === 'extension'
      );
      sendResponse({ extensions: userExtensions });
    });
    return true;
  }
  
  if (request.action === 'toggleExtension') {
    chrome.management.setEnabled(request.extensionId, request.enabled, () => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'getBlockedDomains') {
    chrome.storage.sync.get(['blockedDomains', 'enabled'], (result) => {
      sendResponse(result);
    });
    return true;
  }
  
  if (request.action === 'setBlockedDomains') {
    chrome.storage.sync.set({ 
      blockedDomains: request.domains,
      enabled: request.enabled 
    }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
});
